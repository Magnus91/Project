package no.uio.ifi.asp.scanner;

import java.io.*;
import java.util.*;

import no.uio.ifi.asp.main.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class Scanner {
    private LineNumberReader sourceFile = null;
    private String curFileName;
    private ArrayList<Token> curLineTokens = new ArrayList<>();
    private int indents[] = new int[100];
    private int numIndents = 0;
    private final int tabDist = 4;


    public Scanner(String fileName) {
        curFileName = fileName;
        indents[0] = 0;  numIndents = 1;

        try {
            sourceFile = new LineNumberReader(
                    new InputStreamReader(
                    new FileInputStream(fileName),
                    "UTF-8"));
        } catch (IOException e) {
            scannerError("Cannot read " + fileName + "!");
        }
    }


    private void scannerError(String message) {
        String m = "Asp scanner error";
        if (curLineNum() > 0)
            m += " on line " + curLineNum();
        m += ": " + message;

        Main.error(m);
    }


    public Token curToken() {
        while (curLineTokens.isEmpty()) {
            readNextLine();
        }
        return curLineTokens.get(0);
    }


    public void readNextToken() {
        if (! curLineTokens.isEmpty())
            curLineTokens.remove(0);
    }


    public boolean anyEqualToken() {
        for (Token t: curLineTokens) {
            if (t.kind == equalToken) return true;
        }
        return false;
    }


    private void readNextLine() {
        curLineTokens.clear();

        // Read the next line:
        String line = null;
        try {
            line = sourceFile.readLine();
            if (line == null) {
                sourceFile.close();
                sourceFile = null;
            } else {
                Main.log.noteSourceLine(curLineNum(), line);
            }
        } catch (IOException e) {
            sourceFile = null;
            scannerError("Unspecified I/O error!");
        }

        //-- Must be changed in part 1:

        /* Checks to see if we have reached end of file.
         * If we have, add as many dedent-tokens as there have been indents.
         * Then add an end-of-file token, log it and return.
         */
        if(sourceFile == null) {
            for(int i = 0; i < numIndents; i ++) {
                if(indents[i] > 0) {
                    curLineTokens.add(new Token(dedentToken, curLineNum()));
                }
            }
            curLineTokens.add(new Token(eofToken, curLineNum()));
            for (Token t: curLineTokens) {
                Main.log.noteToken(t);
            }
            return;
        }

        // Turn leading tabs into spaces, and count them.
		int leadingSpaces = findIndent((expandLeadingTabs(line)));

        /* For each line, check if leading spaces is bigger or smaller than current indents.
         * If leading spaces is bigger, we add a new indent-token. If leading spaces is smaller,
         * we add a new dedent-token.
         */

        if(line.matches("^\\s*$")) { // Checks if line is empty or only whitespaces
            return;
        }
        if (leadingSpaces > indents[numIndents-1]) {
            indents[numIndents] = leadingSpaces;
            numIndents++;
            curLineTokens.add(new Token(indentToken,curLineNum()));
        } else if (leadingSpaces < indents[numIndents-1]) {
            while (leadingSpaces < indents[numIndents-1]) {
                indents[numIndents] = 0;
                numIndents--;
                curLineTokens.add(new Token(dedentToken, curLineNum()));
            }
        }
        /* If, after doing the tests above, leading spaces is not equal to the current indents
         * we have an indentation error.
         */

        if (indents[numIndents-1] != leadingSpaces) {
            System.out.println("Indentation error on line " + curLineNum());
        }

        // Adding tokens
        String tokenString = "";
        Token newToken;
        loop: for(int i = 0; i< line.length(); i++) {

            char c = line.charAt(i);
            boolean  isKeyword = false;

            // Checks if the char is a letter or _ and adds it as a name token or a keyword if a match is found.
            if (isLetterAZ(c)) {
                tokenString += c;
                i++;

                while ((i < line.length()) && (isLetterAZ(line.charAt(i)) || isDigit(line.charAt(i)))) {
                    tokenString += line.charAt(i);
                    i++;
                }
                i--;

                for (TokenKind tk : EnumSet.range(andToken, yieldToken)) {
                    if (tokenString.equals(tk.toString())) {
                        curLineTokens.add(new Token(tk, curLineNum()));
                        isKeyword = true;
                    }
                }
                if (!isKeyword) {
                    newToken = new Token(nameToken, curLineNum());
                    newToken.name = tokenString;
                    curLineTokens.add(newToken);
                }
                tokenString = "";

            // Check if the char is a digit
            } else if(isDigit(c)) {
                boolean isFloat = false;
                tokenString += c;
                i++;

                while(i < line.length() && isDigit(line.charAt(i))) {
                    tokenString += line.charAt(i);
                    i++;
                }

                if ((i < line.length()) && line.charAt(i) == '.') {
                    tokenString += line.charAt(i);
                    isFloat = true;
                    i++;

                    while(i < line.length() && isDigit(line.charAt(i))) {
                        tokenString += line.charAt(i);
                        i++;
                    }
                }

                // If the next char is a letter or _ it adds it as a name token instead. (This is of course illegal for the parser)
                if (i < line.length() && isLetterAZ(line.charAt(i))) {
                    while ((i < line.length()) && (isLetterAZ(line.charAt(i)) || isDigit(line.charAt(i)))) {
                        tokenString += line.charAt(i);
                        i++;
                    }
                    newToken = new Token(nameToken, curLineNum());
                    newToken.name = tokenString;
                } else { // If the next char is not a letter or _ it adds it as an integer or float.
                    if(isFloat) {
                        newToken = new Token(floatToken, curLineNum());
                        newToken.floatLit = Double.parseDouble(tokenString);
                    } else {
                        newToken = new Token(integerToken, curLineNum());
                        newToken.integerLit = Long.parseLong(tokenString);
                    }
                }
                i--;

                curLineTokens.add(newToken);
                tokenString = "";

            } else {

                /* If the char is not the start of a name token, keyword token or digit token a switch case is started.
                 * We could have done this using the same technique as for the keyword tokens above, but we had already
                 * written most of this switch case before realizing that. The efficiency of the switch case vs the other
                 * solution is rather insignificant, it's just an unnecessary amount of lines of code. For now we won't
                 * change that; the functionality is there. Might decide to make changes in the future.
                 */
                switch (c) {

                    // Unique delimiter and operator Tokens
                    case '~':
                        curLineTokens.add(new Token(tildeToken, curLineNum()));
                        break;

                    case '@':
                        curLineTokens.add(new Token(atToken, curLineNum()));
                        break;

                    case ':':
                        curLineTokens.add(new Token(colonToken, curLineNum()));
                        break;

                    case ',':
                        curLineTokens.add(new Token(commaToken, curLineNum()));
                        break;

                    case '.':
                        curLineTokens.add(new Token(dotToken, curLineNum()));
                        break;

                    case '{':
                        curLineTokens.add(new Token(leftBraceToken, curLineNum()));
                        break;

                    case '[':
                        curLineTokens.add(new Token(leftBracketToken, curLineNum()));
                        break;

                    case '(':
                        curLineTokens.add(new Token(leftParToken, curLineNum()));
                        break;

                    case '}':
                        curLineTokens.add(new Token(rightBraceToken, curLineNum()));
                        break;

                    case ']':
                        curLineTokens.add(new Token(rightBracketToken, curLineNum()));
                        break;

                    case ')':
                        curLineTokens.add(new Token(rightParToken, curLineNum()));
                        break;

                    case ';':
                        curLineTokens.add(new Token(semicolonToken, curLineNum()));
                        break;

                    case '!':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            curLineTokens.add(new Token(notEqualToken, curLineNum()));
                        }
                        break;

                    // String tokens
                    case '"':
                        i++;
                        while (line.charAt(i) != '"') {
                            tokenString += line.charAt(i);
                            i++;
                        }
                        newToken = new Token(stringToken, curLineNum());
                        newToken.stringLit = tokenString;
                        curLineTokens.add(newToken);
                        tokenString = "";
                        break;

                    case '\'':
                        i++;
                        while (line.charAt(i) != '\'') {
                            tokenString += line.charAt(i);
                            i++;
                        }
                        newToken = new Token(stringToken, curLineNum());
                        newToken.stringLit = tokenString;
                        curLineTokens.add(newToken);
                        tokenString = "";
                        break;

                    // Remaining operator and delimiter tokens
                    case '&':
                        i++;

                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(ampEqualToken, curLineNum());
                        } else {
                            newToken = new Token(ampToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '*':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '*') {
                            i++;
                            if ((i < line.length()) && line.charAt(i) == '=') {
                                newToken = new Token(doubleAstEqualToken, curLineNum());
                            } else {
                                newToken = new Token(doubleAstToken, curLineNum());
                                i--;
                            }
                        } else if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(astEqualToken, curLineNum());
                        } else {
                            newToken = new Token(astToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '|':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(barEqualToken, curLineNum());
                        } else {
                            newToken = new Token(barToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '=':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(doubleEqualToken, curLineNum());
                        } else {
                            newToken = new Token(equalToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '>':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '>') {
                            i++;
                            if ((i < line.length()) && line.charAt(i) == '=') {
                                newToken = new Token(doubleGreaterEqualToken, curLineNum());
                            } else {
                                newToken = new Token(doubleGreaterToken, curLineNum());
                                i--;
                            }
                        }  else if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(greaterEqualToken, curLineNum());
                        } else {
                            newToken = new Token(greaterToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '<':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '<') {
                            i++;
                            if ((i < line.length()) && line.charAt(i) == '=') {
                                newToken = new Token(doubleLessEqualToken, curLineNum());
                            } else {
                                newToken = new Token(doubleLessToken, curLineNum());
                                i--;
                            }
                        }  else if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(lessEqualToken, curLineNum());
                        } else {
                            newToken = new Token(lessToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '/':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '/') {
                            i++;
                            if ((i < line.length()) && line.charAt(i) == '=') {
                                newToken = new Token(doubleSlashEqualToken, curLineNum());
                            } else {
                                newToken = new Token(doubleSlashToken, curLineNum());
                                i--;
                            }
                        } else if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(slashEqualToken, curLineNum());
                        } else {
                            newToken = new Token(slashToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '^':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(hatEqualToken, curLineNum());
                        } else {
                            newToken = new Token(hatToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '-':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(minusEqualToken, curLineNum());
                        } else {
                            newToken = new Token(minusToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '%':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(percentEqualToken, curLineNum());
                        } else {
                            newToken = new Token(percentToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '+':
                        i++;
                        if ((i < line.length()) && line.charAt(i) == '=') {
                            newToken = new Token(plusEqualToken, curLineNum());
                        } else {
                            newToken = new Token(plusToken, curLineNum());
                            i--;
                        }
                        curLineTokens.add(newToken);
                        break;

                    case '#':
                        return;

                    case ' ':
                        break;

                    case '\t':
                        break;

                    default:
                        System.out.println("No added functionality for this char yet: " + c);
                        break;
                }
            }
        }

        // Terminate line:
        if (!line.isEmpty()) {
            curLineTokens.add(new Token(newLineToken, curLineNum()));
        }
        for (Token t: curLineTokens) {
            Main.log.noteToken(t);
        }
    }

    public int curLineNum() {
	return sourceFile!=null ? sourceFile.getLineNumber() : 0;
    }

    private int findIndent(String s) {
        int indent = 0;

        while (indent<s.length() && s.charAt(indent)==' ') indent++;
        return indent;
    }

    private String expandLeadingTabs(String s) {
        String newS = "";
        for (int i = 0;  i < s.length();  i++) {
            char c = s.charAt(i);
            if (c == '\t') {
            do {
                newS += " ";
            } while (newS.length()%tabDist != 0);
            } else if (c == ' ') {
            newS += " ";
            } else {
            newS += s.substring(i);
            break;
            }
        }
        return newS;
    }


    private boolean isLetterAZ(char c) {
	return ('A'<=c && c<='Z') || ('a'<=c && c<='z') || (c=='_');
    }


    private boolean isDigit(char c) {
	return '0'<=c && c<='9';
    }


    public boolean isCompOpr() {
        TokenKind k = curToken().kind;
        switch (k) {
            case lessToken:
            case greaterToken:
            case doubleEqualToken:
            case greaterEqualToken:
            case lessEqualToken:
            case notEqualToken:
                return true;
            default:
                return false;
        }
    }


    public boolean isFactorPrefix() {
        TokenKind k = curToken().kind;
        switch (k) {
            case plusToken:
            case minusToken:
                return true;
            default:
                return false;
        }
    }


    public boolean isFactorOpr() {
        TokenKind k = curToken().kind;
        switch (k) {
            case astToken:
            case slashToken:
            case percentToken:
            case doubleSlashToken:
                return true;
            default:
                return false;
        }
    }
	
    public boolean isTermOpr() {
        TokenKind k = curToken().kind;
        switch (k) {
            case plusToken:
            case minusToken:
                return true;
            default:
                return false;
        }
    }
}