package no.uio.ifi.asp.runtime;

import no.uio.ifi.asp.parser.AspSyntax;

import java.util.HashMap;

public class RuntimeDictValue extends RuntimeValue {
    HashMap<String, RuntimeValue> dictValue;
    boolean boolValue;

    public RuntimeDictValue (HashMap<String, RuntimeValue> v)  {
        dictValue = v;
        if (v.isEmpty())
            boolValue = false;
        else
            boolValue = true;
    }

    @Override
    protected String typeName() {
        return "dictionary";
    }

    @Override
    public String toString() {
        String str = "{";

        Object[] keys = dictValue.keySet().toArray();

        for (int i = 0; i < keys.length; i++) {
            str += keys[i].toString()+":";
            str += dictValue.get(keys[i]).toString();
            if (i+1 != keys.length) {
                str += ", ";
            }
        }
        str += "}";
        return str;
    }

    @Override
    public HashMap<String, RuntimeValue> getDictValue(String what, AspSyntax where) {
        return dictValue;
    }
    @Override
    public boolean getBoolValue(String what, AspSyntax where) {
        return boolValue;
    }

    @Override
    public RuntimeValue evalNot(AspSyntax where) {
        return new RuntimeBoolValue(!boolValue);
    }

    @Override
    public RuntimeValue evalSubscription(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof RuntimeIntValue) {
            long num = v.getIntValue("subscription", where);
            res = dictValue.get(String.valueOf((int)num));
        } else if(v instanceof RuntimeStringValue) {
            String key = v.getStringValue("subscription", where);
            res = dictValue.get(key);
        } else if(v instanceof RuntimeFloatValue) {
            double num = v.getFloatValue("subscription", where);
            res = dictValue.get(String.valueOf(num));
        } else if(v instanceof RuntimeBoolValue) {
            boolean bool = v.getBoolValue("subscription", where);
            res = dictValue.get(String.valueOf(bool));
        } else {
            runtimeError("Type error for subscription.", where);
        }
        return res;
    }


    @Override
    public RuntimeValue evalLen(AspSyntax where) {
        return new RuntimeIntValue(dictValue.size());
    }


    @Override
    public void evalAssignElem(RuntimeValue inx, RuntimeValue val, AspSyntax where) {
        String key = inx.getStringValue("Assign Elem", where);
        dictValue.replace(key, val);
    }
}
