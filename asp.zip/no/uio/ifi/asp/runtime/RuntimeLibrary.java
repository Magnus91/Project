package no.uio.ifi.asp.runtime;

import java.util.ArrayList;
import java.util.Scanner;

import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeLibrary extends RuntimeScope {
    private Scanner keyboard = new Scanner(System.in);

    public RuntimeLibrary() {

        // len
        assign("len", new RuntimeFunc("len") {
            @Override
            public RuntimeValue evalFuncCall(
                    ArrayList<RuntimeValue> actualParams,
                    AspSyntax where) {
                checkNumParams(actualParams, 1, "len", where);
                return actualParams.get(0).evalLen(where);
            }});

        // print
        assign("print", new RuntimeFunc("print") {
            @Override
            public RuntimeValue evalFuncCall(
                    ArrayList<RuntimeValue> actualParams,
                    AspSyntax where) {
                String txt = "";
                for(int i = 0; i < actualParams.size(); i++) {
                    txt += actualParams.get(i) + " ";
                }
                System.out.println(txt);
                return new RuntimeStringValue(txt);
            }});

        // input
        assign("input", new RuntimeFunc("input") {
            @Override
            public RuntimeValue evalFuncCall(
                    ArrayList<RuntimeValue> actualParams,
                    AspSyntax where) {
                String txt = "";
                if(actualParams.size()!= 0) {
                    System.out.print(actualParams.get(0));
                    txt = keyboard.nextLine();
                    checkNumParams(actualParams, 1, "input", where);
                } else {
                    txt = keyboard.nextLine();
                    checkNumParams(actualParams, 0, "input", where);
                }
                return new RuntimeStringValue(txt);
            }});

        // str
        assign("str", new RuntimeFunc("str") {
            @Override
            public RuntimeValue evalFuncCall(
                    ArrayList<RuntimeValue> actualParams,
                    AspSyntax where) {
                return new RuntimeStringValue(actualParams.get(0).toString());
            }});

        // int
        assign("int", new RuntimeFunc("int") {
            @Override
            public RuntimeValue evalFuncCall(
                    ArrayList<RuntimeValue> actualParams,
                    AspSyntax where) {
                return new RuntimeIntValue(actualParams.get(0).getIntValue("int", where));
            }});

        // float
        assign("float", new RuntimeFunc("float") {
            @Override
            public RuntimeValue evalFuncCall(
                    ArrayList<RuntimeValue> actualParams,
                    AspSyntax where) {
                return new RuntimeFloatValue(actualParams.get(0).getFloatValue("float", where));
            }});
    }

    private void checkNumParams(ArrayList<RuntimeValue> actArgs, 
				int nCorrect, String id, AspSyntax where) {
	if (actArgs.size() != nCorrect)
	    RuntimeValue.runtimeError("Wrong number of parameters to "+id+"!",where);
    }
}
