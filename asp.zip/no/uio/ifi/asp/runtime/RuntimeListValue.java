package no.uio.ifi.asp.runtime;

import no.uio.ifi.asp.parser.AspArguments;
import no.uio.ifi.asp.parser.AspSyntax;
import java.util.ArrayList;
import java.util.Arrays;

public class RuntimeListValue extends RuntimeValue {
    ArrayList<RuntimeValue> listValue;
    boolean boolValue;

    public RuntimeListValue(ArrayList<RuntimeValue> v) {
        listValue = v;
        if(v.isEmpty())
            boolValue = false;
        else
            boolValue = true;
    }

    @Override
    protected String typeName() {
        return "list";
    }

    @Override
    public String toString() {
        String str = Arrays.toString(listValue.toArray());
        return str;
    }

    @Override
    public ArrayList<RuntimeValue> getListValue(String what, AspSyntax where) {
        return listValue;
    }

    @Override
    public boolean getBoolValue(String what, AspSyntax where) {
        return boolValue;
    }

    @Override
    public RuntimeValue evalNot(AspSyntax where) {
        return new RuntimeBoolValue(!boolValue);
    }

    @Override
    public  RuntimeValue evalAdd(RuntimeValue v, AspSyntax where) {
        ArrayList<RuntimeValue> res = listValue;
        if(v instanceof  RuntimeListValue) {
            ArrayList<RuntimeValue> tmpList = v.getListValue("+ operand", where);
            for(int i = 0; i < tmpList.size(); i++) {
                res.add(tmpList.get(i));
            }
        } else {
            runtimeError("Type error for +.", where);
        }
        return new RuntimeListValue(res);
    }

    @Override
    public RuntimeValue evalMultiply(RuntimeValue v, AspSyntax where) {
        ArrayList<RuntimeValue> res = listValue;
        if(v instanceof  RuntimeIntValue) {
            long multiplier = v.getIntValue("* operand", where);
            int startSize = listValue.size();
            for(int i = 1; i < multiplier; i++) {
                for(int j = 0; j < startSize ; j++) {
                    res.add(listValue.get(j)) ;
                }
            }
        } else {
            runtimeError("Type error for *.", where);
        }
        return new RuntimeListValue(res);
    }

    @Override
    public RuntimeValue evalSubscription(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof RuntimeIntValue) {
           long num = v.getIntValue("subscription", where);
           res = listValue.get((int)num);
        } else {
            runtimeError("Type error for subscription.", where);
        }
        return res;
    }
    @Override
    public RuntimeValue evalLen(AspSyntax where) {
        return new RuntimeIntValue(listValue.size());
    }

    @Override
    public void evalAssignElem(RuntimeValue inx, RuntimeValue val, AspSyntax where) {
        int index = (int)inx.getIntValue("Assign Elem", where);
        listValue.set(index, val);
    }
}

