package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspTermOpr extends AspSyntax {
    Token termOpr;
    AspTermOpr(int n) {
        super(n);
    }

    static AspTermOpr parse(Scanner s) {

        Main.log.enterParser("term opr");
        AspTermOpr ato = new AspTermOpr(s.curLineNum());

        switch(s.curToken().kind) {
            case plusToken:
                ato.termOpr = s.curToken();
                skip(s, plusToken);

                break;
            case minusToken:
                ato.termOpr = s.curToken();
                skip(s, minusToken);
                break;
            default:
                parserError("Expected a term opr but found a " +
                        s.curToken().kind + "!", s.curLineNum());
        }

        Main.log.leaveParser("term opr");
        return ato;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(" " + termOpr.kind.toString() + " ");
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return null; // AspTerm takes care of the evaluations
    }
}
