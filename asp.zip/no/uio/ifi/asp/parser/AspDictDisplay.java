package no.uio.ifi.asp.parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspDictDisplay extends AspAtom {

    ArrayList<AspExpr> exprs = new ArrayList<>();
    ArrayList<AspStringLiteral> stringLits = new ArrayList<>();

    AspDictDisplay(int n) {
        super(n);
    }

    static AspDictDisplay parse(Scanner s) {
        Main.log.enterParser("dict display");
        AspDictDisplay add = new AspDictDisplay(s.curLineNum());

        skip(s, leftBraceToken);

        while (true) {
            if (s.curToken().kind == rightBraceToken) break;
            add.stringLits.add(AspStringLiteral.parse(s));
            skip(s, colonToken);
            add.exprs.add(AspExpr.parse(s));
            if (s.curToken().kind != commaToken) break;
            skip(s, commaToken);
        }

        skip(s, rightBraceToken);

        Main.log.leaveParser("dict display");
        return add;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite("{");
        for(int i = 0; i < stringLits.size(); i++) {
            stringLits.get(i).prettyPrint();
            Main.log.prettyWrite(":");
            exprs.get(i).prettyPrint();
            if (i+1 < stringLits.size())
                Main.log.prettyWrite(", ");
        }
        Main.log.prettyWrite("}");
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        //-- Must be changed in part 3:
        HashMap<String, RuntimeValue> map = new HashMap<>();
        for (int i = 0; i < stringLits.size(); i++) {
            map.put(stringLits.get(i).value, exprs.get(i).eval(curScope));
        }
        return new RuntimeDictValue(map);
    }
}
