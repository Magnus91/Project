package no.uio.ifi.asp.parser;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;
import java.util.ArrayList;


public class AspIfStmt extends AspStmt {

    ArrayList<AspExpr> aspExprs = new ArrayList<>();
    ArrayList<AspSuite> aspSuites = new ArrayList<>();
    AspSuite last = null;


    AspIfStmt(int n) {
        super(n);
    }

    static AspIfStmt parse(Scanner s) {
        Main.log.enterParser("if stmt");
        AspIfStmt ais = new AspIfStmt(s.curLineNum());
        skip(s, ifToken);
        while(true) {
            ais.aspExprs.add(AspExpr.parse(s));
            skip(s, colonToken);
            ais.aspSuites.add(AspSuite.parse(s));
            if(s.curToken().kind != elifToken) {
                break;
            }
            skip(s, elifToken);
        }
        if(s.curToken().kind == elseToken) {
            skip(s, elseToken);
            skip(s, colonToken);
            ais.last = AspSuite.parse(s);
        }
        Main.log.leaveParser("if stmt");
        return ais;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite("if ");
        int nPrinted = 0;
        int i = 0;
        for (AspExpr ae: aspExprs) {
            if (nPrinted > 0)
                Main.log.prettyWrite("elif ");
            ae.prettyPrint();
            Main.log.prettyWrite(":");
            aspSuites.get(i).prettyPrint();
            nPrinted++;
            i++;
        }
        if (last != null) {
            Main.log.prettyWrite("else");
            Main.log.prettyWrite(":");
            last.prettyPrint();
        }
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        RuntimeValue v = null;
        RuntimeValue suite = null;
        boolean anyTrue = false;
        for(int i = 0; i < aspExprs.size(); i++) {
            v = aspExprs.get(i).eval(curScope);
            if(v.getBoolValue("if stmt", this)) {
                trace("if True alt #" + (i+1) + ":");
                suite = aspSuites.get(i).eval(curScope);
                anyTrue = true;
                break;
            }
        }
        if(!anyTrue) {
            trace("else: ...");
            if(last != null) {
                suite = last.eval(curScope);
            }
        }
        return v;
    }
}
