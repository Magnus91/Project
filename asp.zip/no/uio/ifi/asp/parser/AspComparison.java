package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspComparison extends AspSyntax {

    ArrayList<AspTerm> aspTerms = new ArrayList<>();
    ArrayList<AspCompOpr> aspCompOprs = new ArrayList<>();

    AspComparison(int n) {
        super(n);
    }

    static AspComparison parse(Scanner s) {
        Main.log.enterParser("comparison");
        AspComparison ac = new AspComparison(s.curLineNum());
        while(true) {
            ac.aspTerms.add(AspTerm.parse(s));
            if(s.isCompOpr()) {
                ac.aspCompOprs.add(AspCompOpr.parse(s));
            } else {
                break;
          }
        }
        Main.log.leaveParser("comparison");
        return ac;
    }

    @Override
    void prettyPrint() {
        int i = 0;
        for (AspTerm at: aspTerms) {
            at.prettyPrint();
            if (i < aspCompOprs.size())
                aspCompOprs.get(i).prettyPrint();
            i++;
        }
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        RuntimeValue bool = aspTerms.get(0).eval(curScope);
        RuntimeValue v = bool;

        for (int i = 1; i < aspTerms.size(); i++) {
            TokenKind k = aspCompOprs.get(i-1).compOpr.kind;
            switch(k) {
                case lessToken:
                    bool = v.evalLess(aspTerms.get(i).eval(curScope), this);
                    v = aspTerms.get(i).eval(curScope);
                    if (!bool.getBoolValue("and operand",this))
                        return bool;
                    break;
                case greaterToken:
                    bool = v.evalGreater(aspTerms.get(i).eval(curScope), this);
                    v = aspTerms.get(i).eval(curScope);
                    if (!bool.getBoolValue("and operand",this))
                        return bool;
                    break;
                case doubleEqualToken:
                    bool = v.evalEqual(aspTerms.get(i).eval(curScope), this);
                    v = aspTerms.get(i).eval(curScope);
                    if (!bool.getBoolValue("and operand",this))
                        return bool;
                    break;
                case greaterEqualToken:
                    bool = v.evalGreaterEqual(aspTerms.get(i).eval(curScope), this);
                    v = aspTerms.get(i).eval(curScope);
                    if (!bool.getBoolValue("and operand",this))
                        return bool;
                    break;
                case lessEqualToken:
                    bool = v.evalLessEqual(aspTerms.get(i).eval(curScope), this);
                    v = aspTerms.get(i).eval(curScope);
                    if (!bool.getBoolValue("and operand",this))
                        return bool;
                    break;
                case notEqualToken:
                    bool = v.evalNotEqual(aspTerms.get(i).eval(curScope), this);
                    v = aspTerms.get(i).eval(curScope);
                    if (!bool.getBoolValue("and operand",this))
                        return bool;
                    break;
                default:
                    Main.panic("Illegal comp operator: " + k + "!");
            }
        }
        return bool;
    }
}
