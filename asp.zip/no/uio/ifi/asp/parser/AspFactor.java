package no.uio.ifi.asp.parser;

import java.awt.image.AreaAveragingScaleFilter;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFactor extends AspSyntax {

    AspFactorPrefix aspFactorPrefix;
    ArrayList<AspPrimary> aspPrimaries = new ArrayList<>();
    ArrayList<AspFactorOpr> aspFactorOprs = new ArrayList<>();

    AspFactor(int n) {
        super(n);
    }

    static AspFactor parse(Scanner s) {

        Main.log.enterParser("fact test");

        AspFactor af = new AspFactor(s.curLineNum());
        if(s.isFactorPrefix()) {
            af.aspFactorPrefix = AspFactorPrefix.parse(s);
        }
        while(true) {
            af.aspPrimaries.add(AspPrimary.parse(s));
            if(s.isFactorOpr()) {
                af.aspFactorOprs.add(AspFactorOpr.parse(s));
            } else {
                break;
            }
        }

        Main.log.leaveParser("factor");
        return af;
    }

    @Override
    void prettyPrint() {
        if(aspFactorPrefix != null) {
            aspFactorPrefix.prettyPrint();
        }
        for(int i = 0; i < aspPrimaries.size(); i++) {
            aspPrimaries.get(i).prettyPrint();
            if(i < aspFactorOprs.size()) {
                aspFactorOprs.get(i).prettyPrint();
            }
        }
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {

        RuntimeValue v = aspPrimaries.get(0).eval(curScope);

        if (aspFactorPrefix != null) {
            TokenKind k = aspFactorPrefix.aspFactorPrefix.kind;
            switch(k) {
                case minusToken:
                    v = v.evalNegate(this);
                    break;
                case plusToken:
                    v = v.evalPositive(this);
                    break;
                default:
                    Main.panic("Illegal factor prefix: " + k + "!");
            }
        }

        for (int i = 1; i < aspPrimaries.size(); i++) {
            TokenKind k = aspFactorOprs.get(i-1).factorOpr.kind;
            switch(k) {
                case astToken:
                    v = v.evalMultiply(aspPrimaries.get(i).eval(curScope), this);
                    break;
                case slashToken:
                    v = v.evalDivide(aspPrimaries.get(i).eval(curScope), this);
                    break;
                case percentToken:
                    v = v.evalModulo(aspPrimaries.get(i).eval(curScope), this);
                    break;
                case doubleSlashToken:
                    v = v.evalIntDivide(aspPrimaries.get(i).eval(curScope), this);
                    break;
                default:
                    Main.panic("Illegal term operator: " + k + "!");
            }
        }

        return v;
    }
}
