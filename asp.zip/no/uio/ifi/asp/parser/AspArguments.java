package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspArguments extends AspPrimarySuffix {

    ArrayList<AspExpr> exprs = new ArrayList<>();

    AspArguments (int n) {
        super(n);
    }

    static AspArguments parse(Scanner s) {
        Main.log.enterParser("arguments");
        AspArguments aa = new AspArguments(s.curLineNum());

        skip(s, leftParToken);

        while (true) {
            if (s.curToken().kind == rightParToken) break;
            aa.exprs.add(AspExpr.parse(s));
            if (s.curToken().kind != commaToken) break;
            skip(s, commaToken);
        }

        skip(s, rightParToken);

        Main.log.leaveParser("arguments");
        return aa;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite("(");
        int nPrinted = 0;
        for(AspExpr ae: exprs) {
            if (nPrinted > 0)
                Main.log.prettyWrite(", ");
            ae.prettyPrint();
            nPrinted++;
        }
        Main.log.prettyWrite(")");
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        RuntimeValue v;
        ArrayList<RuntimeValue> listValue = new ArrayList<>();
        for (int i = 0; i < exprs.size(); i++) {
            v = exprs.get(i).eval(curScope);
            listValue.add(v);
        }
        return new RuntimeListValue(listValue);
    }
}
