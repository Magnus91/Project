package no.uio.ifi.asp.parser;


import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.scanner.*;

abstract public class AspPrimarySuffix extends AspSyntax {

    AspPrimarySuffix(int n) {
        super(n);
    }
    static AspPrimarySuffix parse(Scanner s) {

        Main.log.enterParser("primary suffix");
        AspPrimarySuffix a = null;
        switch (s.curToken().kind) {
            case leftBracketToken:
                a = AspSubscription.parse(s);
                break;
            case leftParToken:
                a = AspArguments.parse(s);
                break;

            default:
                parserError("Expected a primary suffix but found a " +
                        s.curToken().kind + "!", s.curLineNum());
        }
        Main.log.leaveParser("primary suffix");
        return a;
    }
}
