package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFactorOpr extends AspSyntax {
    Token factorOpr;
    AspFactorOpr(int n) {
        super(n);
    }

    static AspFactorOpr parse(Scanner s) {
        Main.log.enterParser("factOpr test");
        AspFactorOpr afo = new AspFactorOpr(s.curLineNum());

        switch(s.curToken().kind) {
            case astToken:
                afo.factorOpr = s.curToken();
                skip(s, astToken);
                break;
            case slashToken:
                afo.factorOpr = s.curToken();
                skip(s, slashToken);
                break;
            case percentToken:
                afo.factorOpr = s.curToken();
                skip(s, percentToken);
                break;
            case doubleSlashToken:
                afo.factorOpr = s.curToken();
                skip(s, doubleSlashToken);
                break;
            default:
                parserError("Expected a factor opr but found a " +
                        s.curToken().kind + "!", s.curLineNum());
        }

        Main.log.leaveParser("factOpr test");
        return afo;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(" " + factorOpr.kind.toString() + " ");
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return null;
    }
}
