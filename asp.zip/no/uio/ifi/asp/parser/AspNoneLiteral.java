package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspNoneLiteral extends AspAtom {

    Token aspNone;
    AspNoneLiteral (int n) {
        super(n);
    }

    static AspNoneLiteral parse(Scanner s) {

        Main.log.enterParser("none literal");
        AspNoneLiteral anl = new AspNoneLiteral(s.curLineNum());
        anl.aspNone = s.curToken();
        skip(s, noneToken);
        Main.log.leaveParser("none literal");
        return anl;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(" " + aspNone.kind.toString() + " ");

    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return null;
    }
}
