package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspStringLiteral extends AspAtom {

    Token aspString;
    String value;

    AspStringLiteral(int n) {
        super(n);
    }

    static AspStringLiteral parse(Scanner s) {

        Main.log.enterParser("string literal");
        AspStringLiteral asl = new AspStringLiteral(s.curLineNum());
        asl.aspString = s.curToken();
        asl.value = asl.aspString.stringLit;
        skip(s, stringToken);
        Main.log.leaveParser("string literal");
        return asl;
    }

    //In the log files, all outputs use '"', so we'll just do that as well.
    @Override
    void prettyPrint() {
        Main.log.prettyWrite('"' + aspString.stringLit + '"');

    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return new RuntimeStringValue(value);
    }

}
