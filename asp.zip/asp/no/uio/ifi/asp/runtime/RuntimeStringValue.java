package no.uio.ifi.asp.runtime;

import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeStringValue extends RuntimeValue {
    String strValue;
    boolean boolValue;

    public RuntimeStringValue (String v)  {
        strValue = v;
        if (v.equals(""))
            boolValue = false;
        else
            boolValue = true;
    }

    @Override
    public String showInfo() {
        if (strValue.indexOf('\'') >= 0)
            return "\"" + strValue + "\"";
        else
            return "'" + strValue + "'";
    }

    @Override
    protected String typeName() {
        return "String";
    }

    @Override
    public long getIntValue(String what, AspSyntax where) {
        return Integer.parseInt(strValue);
    }

    @Override
    public double getFloatValue(String what, AspSyntax where) {
        return Double.parseDouble(strValue);
    }

    @Override
    public boolean getBoolValue(String what, AspSyntax where) { return boolValue; }

    @Override
    public String toString() {
        return strValue;
    }

    @Override
    public String getStringValue(String what, AspSyntax where) {
        return strValue;
    }

    @Override
    public RuntimeValue evalAdd(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if (v instanceof RuntimeStringValue) {
            String v2 = v.getStringValue("+ operand", where);
            res = new RuntimeStringValue(strValue + v2);
        } else {
            runtimeError("Type error for +.", where);
        }
        return res;
    }
    @Override
    public RuntimeValue evalEqual(RuntimeValue v, AspSyntax where) {
        RuntimeBoolValue ret = new RuntimeBoolValue(false);

        if(v instanceof RuntimeStringValue){
            if(strValue.equals(v.toString())){
                ret = new RuntimeBoolValue(true);
            }
            else {
                return ret;
            }
        }
        return ret;
    }

    @Override
    public RuntimeValue evalGreater(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else {
            return new RuntimeBoolValue(
                    strValue.compareTo(v.getStringValue("> operand",where)) > 0 );
        }
    }

    @Override
    public RuntimeValue evalGreaterEqual(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else {
            return new RuntimeBoolValue(
                    strValue.compareTo(v.getStringValue(">= operand",where)) >= 0 );
        }
    }

    @Override
    public RuntimeValue evalLess(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else {
            return new RuntimeBoolValue(
                    strValue.compareTo(v.getStringValue("< operand",where)) < 0 );
        }
    }

    @Override
    public RuntimeValue evalLessEqual(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else {
            return new RuntimeBoolValue(
                    strValue.compareTo(v.getStringValue("<= operand",where)) <= 0 );
        }
    }


    @Override
    public RuntimeValue evalMultiply(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        String tmp = "";
        if(v instanceof  RuntimeIntValue) {
            long v2 = v.getIntValue("* operand", where);
            for(int i = 0; i < v2; i++) {
                tmp += strValue;
            }
            res = new RuntimeStringValue(tmp);
        } else {
            runtimeError("Type error for *.", where);
        }
        return res;
    }

    public RuntimeValue evalSubscription(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof RuntimeIntValue) {
            long num = v.getIntValue("subscription", where);
            char tmp = strValue.charAt((int)num);
            res = new RuntimeStringValue(String.valueOf(tmp));
        } else {
            runtimeError("Type error for subscription.", where);
        }
        return res;
    }


    @Override
    public RuntimeValue evalNot(AspSyntax where) {
        return new RuntimeBoolValue(!boolValue);
    }

    @Override
    public RuntimeValue evalNotEqual(RuntimeValue v, AspSyntax where) {
        RuntimeBoolValue ret = new RuntimeBoolValue(false);

        if(v instanceof RuntimeStringValue){
            if(!strValue.equals(v.toString())){
                ret = new RuntimeBoolValue(true);
            } else {
                return ret;
            }
        } else if(v instanceof RuntimeIntValue){
                ret = new RuntimeBoolValue(true);
        } else if(v instanceof RuntimeFloatValue) {
                ret = new RuntimeBoolValue(true);
        }
        return ret;
    }
    @Override
    public RuntimeValue evalLen(AspSyntax where) {
        return new RuntimeIntValue(strValue.length());
    }
}
