package no.uio.ifi.asp.runtime;

import no.uio.ifi.asp.parser.AspName;
import no.uio.ifi.asp.parser.AspSyntax;
import no.uio.ifi.asp.parser.AspFuncDef;
import java.util.ArrayList;

public class RuntimeFunc extends RuntimeValue {
    AspFuncDef def;
    RuntimeScope defScope;
    String name;

    public RuntimeFunc(String name){
        this.name = name;
    }

    public RuntimeFunc(AspFuncDef def, RuntimeScope defScope, String name) {
        this.def = def;
        this.defScope = defScope;
        this.name = name;
    }

    protected String typeName(){ return "Function"; }

    public String toString() { return name;}

    public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams,
                                     AspSyntax where){

        checkNumParams(actualParams, def.getParams().size(), name, where);
        RuntimeScope newScope = new RuntimeScope(defScope);
        for(int i = 0; i < actualParams.size(); i++) {
            newScope.assign(def.getParams().get(i).toString(), actualParams.get(i));
        }
        try {
            def.body.eval(newScope);
        } catch (RuntimeReturnValue rrv) {
            return rrv.value;
        }

        return null;
    }

    private void checkNumParams(ArrayList<RuntimeValue> actArgs,
                                int nCorrect, String id, AspSyntax where) {
        if (actArgs.size() != nCorrect)
            RuntimeValue.runtimeError("Wrong number of parameters to "+id+"!",where);
    }
}
