package no.uio.ifi.asp.runtime;

import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeFloatValue extends RuntimeValue{
    double floatValue;
    boolean boolValue;

    public RuntimeFloatValue(double v) {
        floatValue = v;
        if (v == 0.0)
            boolValue = false;
        else
            boolValue = true;
    }
    @Override
    public long getIntValue(String what, AspSyntax where) {
        return (int) floatValue;
    }

    @Override
    protected String typeName() { return "float";}

    @Override
    public boolean getBoolValue(String what, AspSyntax where) { return boolValue; }

    @Override
    public String toString() {
        return String.valueOf(floatValue);
    }

    @Override
    public double getFloatValue(String what, AspSyntax where) {
        return floatValue;
    }

    @Override
    public RuntimeValue evalAdd(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if (v instanceof RuntimeFloatValue) {
            double v2 = v.getFloatValue("+ operand", where);
            res = new RuntimeFloatValue(floatValue + v2);
        } else if (v instanceof RuntimeIntValue) {
            long v2 = v.getIntValue("+ operand", where);
            res = new RuntimeFloatValue(floatValue + v2);
        } else {
            runtimeError("Type error for +.", where);
        }
        return res;
    }


    @Override
    public RuntimeValue evalDivide(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof  RuntimeFloatValue) {
            double v2 = v.getFloatValue("/ operand" , where);
                res = new RuntimeFloatValue(floatValue / v2);
        } else if (v instanceof RuntimeIntValue) {
            long v2 = v.getIntValue("+ operand", where);
            res = new RuntimeFloatValue(floatValue / v2);
        } else {
            runtimeError("Type error for /.", where);
        }
        return res;
    }

    @Override
    public RuntimeValue evalEqual(RuntimeValue v, AspSyntax where) {
        RuntimeBoolValue ret = new RuntimeBoolValue(false);

        if(v instanceof RuntimeIntValue){
            if(floatValue == ((double)v.getIntValue("equal", where))){
                ret = new RuntimeBoolValue(true);
            } else {
                return ret;
            }
        } else if(v instanceof RuntimeFloatValue) {
            if(floatValue == (v.getFloatValue("equal", where))) {
                ret = new RuntimeBoolValue(true);
            } else {
                return ret;
            }
        } else if(v instanceof RuntimeStringValue) {
            return ret;
        }
        return ret;
    }

    @Override
    public RuntimeValue evalGreater(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else if (v instanceof RuntimeFloatValue) {
            return new RuntimeBoolValue(
                    floatValue > v.getFloatValue("> operand",where));
        } else if (v instanceof RuntimeIntValue){
            return new RuntimeBoolValue(
                    floatValue > v.getIntValue("> operand",where));
        } else {
            runtimeError("Type error for >.", where);
        }
        return v;
    }

    @Override
    public RuntimeValue evalGreaterEqual(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else if (v instanceof RuntimeFloatValue) {
            return new RuntimeBoolValue(
                    floatValue > v.getFloatValue(">= operand",where));
        } else if (v instanceof RuntimeIntValue){
            return new RuntimeBoolValue(
                    floatValue > v.getIntValue(">= operand",where));
        } else {
            runtimeError("Type error for >=.", where);
        }
        return v;
    }

    // Needs to be tested
    @Override
    public  RuntimeValue evalIntDivide(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof  RuntimeFloatValue) {
            double v2 = v.getFloatValue("// operand" , where);
            res = new RuntimeFloatValue(Math.floor(floatValue / v2));
        }  else if(v instanceof  RuntimeIntValue) {
            long v2 = v.getIntValue("// operand" , where);
            res = new RuntimeIntValue(Math.floorDiv((int)floatValue, v2));
        } else {
            runtimeError("Type error for //.", where);
        }
        return res;
    }

    @Override
    public RuntimeValue evalLess(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else if (v instanceof RuntimeFloatValue) {
            return new RuntimeBoolValue(
                    floatValue < v.getFloatValue("< operand",where));
        } else if (v instanceof RuntimeIntValue){
            return new RuntimeBoolValue(
                    floatValue < v.getIntValue("< operand",where));
        } else {
            runtimeError("Type error for <.", where);
        }
        return v;
    }

    @Override
    public RuntimeValue evalLessEqual(RuntimeValue v, AspSyntax where) {
        if (v instanceof RuntimeNoneValue) {
            return new RuntimeBoolValue(false);
        } else if (v instanceof RuntimeFloatValue){
            return new RuntimeBoolValue(
                    floatValue <= v.getFloatValue("<= operand",where));
        } else if (v instanceof RuntimeIntValue){
            return new RuntimeBoolValue(
                    floatValue <= v.getIntValue("<= operand",where));
        } else {
            runtimeError("Type error for <=.", where);
        }
        return v;
    }

    @Override
    public RuntimeValue evalModulo(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof  RuntimeFloatValue) {
            double v2 = v.getFloatValue("% operand", where);
            res = new RuntimeFloatValue((floatValue % v2 + v2) % v2);
        } else if (v instanceof RuntimeIntValue) {
            long v2 = v.getIntValue("% operand", where);
            res = new RuntimeFloatValue((floatValue % v2 + v2) % v2);

        } else {
            runtimeError("Type error for %.", where);
        }
        return res;
    }


    @Override
    public RuntimeValue evalMultiply(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if(v instanceof  RuntimeFloatValue) {
            double v2 = v.getFloatValue("* operand", where);
            res = new RuntimeFloatValue(floatValue * v2);
        } else if (v instanceof RuntimeIntValue) {
            long v2 = v.getIntValue("* operand", where);
            res = new RuntimeIntValue((int)floatValue * v2);
        } else {
            runtimeError("Type error for *.", where);
        }
        return res;
    }

    @Override
    public RuntimeValue evalNegate(AspSyntax where) {
        double v = this.getFloatValue("- prefix", where);
        return new RuntimeFloatValue(-v);
    }

    // Probably wrong
    @Override
    public RuntimeValue evalNot(AspSyntax where) {
        return new RuntimeBoolValue(!boolValue);
    }

    @Override
    public RuntimeValue evalNotEqual(RuntimeValue v, AspSyntax where) {
        RuntimeBoolValue ret = new RuntimeBoolValue(false);

        if(v instanceof RuntimeIntValue){
            if(floatValue != ((double)v.getIntValue("equal", where))){
                ret = new RuntimeBoolValue(true);
            } else {
                return ret;
            }
        } else if(v instanceof RuntimeFloatValue) {
            if(floatValue != (v.getFloatValue("equal", where))) {
                ret = new RuntimeBoolValue(true);
            } else {
                return ret;
            }
        } else if(v instanceof RuntimeStringValue) {
            ret = new RuntimeBoolValue(true);
        }

        return ret;
    }

    @Override
    public RuntimeValue evalPositive(AspSyntax where) {
        double v = this.getFloatValue("+ prefix", where);
        return new RuntimeFloatValue(v);
    }

    @Override
    public RuntimeValue evalSubtract(RuntimeValue v, AspSyntax where) {
        RuntimeValue res = null;
        if (v instanceof RuntimeFloatValue) {
            double v2 = v.getFloatValue("- operand", where);
            res = new RuntimeFloatValue(floatValue - v2);
        } else if (v instanceof  RuntimeIntValue) {
            long v2 = v.getIntValue("- operand", where);
            res = new RuntimeIntValue((int) floatValue - v2);
        } else {
            runtimeError("Type error for -.", where);
        }
        return res;
    }
}
