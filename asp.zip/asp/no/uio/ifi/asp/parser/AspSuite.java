package no.uio.ifi.asp.parser;


import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspSuite extends AspSyntax {

    ArrayList<AspStmt> aspStmts = new ArrayList<>();

    AspSuite(int n) {
        super(n);
    }

    static AspSuite parse(Scanner s) {

        Main.log.enterParser("suite");
        AspSuite as = new AspSuite(s.curLineNum());
        skip(s, newLineToken);
        skip(s, indentToken);
        while(s.curToken().kind != dedentToken) {
            as.aspStmts.add(AspStmt.parse(s));
        }
        skip(s, dedentToken);
        Main.log.leaveParser("suite");
        return as;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWriteLn();
        Main.log.prettyIndent();
        for(AspStmt as : aspStmts) {
            as.prettyPrint();
        }
        Main.log.prettyDedent();
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        RuntimeValue v = null;
        for(AspStmt statement: aspStmts) {
            v = statement.eval(curScope);
        }
        return v;
    }
}
