package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspIntegerLiteral extends AspAtom {
    Token i;
    long value;

    AspIntegerLiteral (int n) {
        super(n);
    }

    static AspIntegerLiteral parse(Scanner s) {

        Main.log.enterParser("integer literal");
        AspIntegerLiteral ail = new AspIntegerLiteral(s.curLineNum());
        ail.i = s.curToken();
        ail.value = ail.i.integerLit;
        skip(s, integerToken);
        Main.log.leaveParser("integer literal");
        return ail;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(String.valueOf(i.integerLit));
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return new RuntimeIntValue(value);
    }
}
