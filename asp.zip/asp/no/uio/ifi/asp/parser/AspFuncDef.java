package no.uio.ifi.asp.parser;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;

import java.util.ArrayList;

import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspFuncDef extends AspStmt {

    AspName name;
    private ArrayList<AspName> params = new ArrayList<>();
    public AspSuite body;

    AspFuncDef(int n) {
        super(n);
    }

    static AspFuncDef parse(Scanner s) {
        Main.log.enterParser("func def");
        AspFuncDef afd = new AspFuncDef(s.curLineNum());

        skip(s, defToken);
        afd.name = AspName.parse(s);
        skip(s, leftParToken);

        while (true) {
            if (s.curToken().kind == rightParToken) break;
            afd.params.add(AspName.parse(s));
            if (s.curToken().kind != commaToken) break;
            skip(s, commaToken);
        }

        skip(s, rightParToken);
        skip(s, colonToken);
        afd.body = AspSuite.parse(s);

        Main.log.leaveParser("func def");
        return afd;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite("def ");
        name.prettyPrint();
        Main.log.prettyWrite("(");
        int nPrinted = 0;
        for (AspName an: params) {
            if (nPrinted > 0)
                Main.log.prettyWrite(", ");
            an.prettyPrint();
            nPrinted++;
        }
        Main.log.prettyWrite(")");
        Main.log.prettyWrite(":");
        body.prettyPrint();
        Main.log.prettyWriteLn();
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {

        RuntimeValue funcDef = new RuntimeFunc(this, curScope, name.name.name);
        curScope.assign(name.name.name, funcDef);
        trace("def " + name.name.name);
        return funcDef;
    }

    public ArrayList<AspName> getParams() {
        return params;
    }
}
