package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspCompOpr extends AspSyntax {

    AspCompOpr(int n) {
        super(n);
    }

    Token compOpr;

    static AspCompOpr parse(Scanner s) {
        Main.log.enterParser("comp opr");
        AspCompOpr aco = new AspCompOpr(s.curLineNum());

        switch (s.curToken().kind) {
            case lessToken:
                aco.compOpr = s.curToken();
                skip(s, lessToken);
                break;
            case greaterToken:
                aco.compOpr = s.curToken();
                skip(s, greaterToken);
                break;
            case doubleEqualToken:
                aco.compOpr = s.curToken();
                skip(s, doubleEqualToken);
                break;
            case greaterEqualToken:
                aco.compOpr = s.curToken();
                skip(s, greaterEqualToken);
                break;
            case lessEqualToken:
                aco.compOpr = s.curToken();
                skip(s, lessEqualToken);
                break;
            case notEqualToken:
                aco.compOpr = s.curToken();
                skip(s, notEqualToken);
                break;
            default:
                parserError("Expected a comp opr but found a " +
                        s.curToken().kind + "!", s.curLineNum());
        }

        Main.log.leaveParser("comp opr");
        return aco;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(" " + compOpr.kind.toString() + " ");
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        //-- Must be changed in part 3:
        return null;
    }
}