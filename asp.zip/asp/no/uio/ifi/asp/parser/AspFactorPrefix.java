package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFactorPrefix extends AspSyntax {
    Token aspFactorPrefix;
    AspFactorPrefix(int n) {
        super(n);
    }

    static AspFactorPrefix parse(Scanner s) {
        Main.log.enterParser("factPre test");
        AspFactorPrefix afp = new AspFactorPrefix(s.curLineNum());
        switch(s.curToken().kind) {
            case plusToken:
                afp.aspFactorPrefix = s.curToken();
                skip(s, plusToken);
                break;
            case minusToken:
                afp.aspFactorPrefix = s.curToken();
                skip(s, minusToken);
                break;
            default:
                parserError("Expected a factor prefix but found a " +
                        s.curToken().kind + "!", s.curLineNum());
        }

        Main.log.leaveParser("factPre test");
        return afp;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(" " + aspFactorPrefix.kind.toString() + " ");
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return null;
    }
}
