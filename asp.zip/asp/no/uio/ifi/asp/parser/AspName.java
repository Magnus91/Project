package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspName extends AspAtom {
    Token name;
    AspName(int n) {
        super(n);
    }

    static AspName parse(Scanner s) {

        Main.log.enterParser("name");
        AspName an = new AspName(s.curLineNum());
        an.name = s.curToken();
        skip(s, nameToken);
        Main.log.leaveParser("name");
        return an;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(name.name);
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return curScope.find(name.name, this);
    }
    public String toString() {
        return name.name;
    }
}
