package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspTerm extends AspSyntax {

    ArrayList<AspTermOpr> aspTermOprs = new ArrayList<>();
    ArrayList<AspFactor> aspFactors = new ArrayList<>();

    AspTerm(int n) {
        super(n);
    }

    static AspTerm parse(Scanner s) {

        Main.log.enterParser("term");
        AspTerm at = new AspTerm(s.curLineNum());
        while(true) {
            at.aspFactors.add(AspFactor.parse(s));
            if(s.isTermOpr()) {
                at.aspTermOprs.add(AspTermOpr.parse(s));
            } else {
                break;
            }
        }

        Main.log.leaveParser("term");
        return at;
    }

    @Override
    void prettyPrint() {
        for(int i = 0; i < aspFactors.size(); i++) {
            aspFactors.get(i).prettyPrint();
            if(i < aspTermOprs.size()) {
                aspTermOprs.get(i).prettyPrint();
            }
        }
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        RuntimeValue v = aspFactors.get(0).eval(curScope);
        for (int i = 1; i < aspFactors.size(); i++) {
            TokenKind k = aspTermOprs.get(i-1).termOpr.kind;
            switch(k) {
                case minusToken:
                    v = v.evalSubtract(aspFactors.get(i).eval(curScope), this);
                    break;
                case plusToken:
                    v = v.evalAdd(aspFactors.get(i).eval(curScope), this);
                    break;
                default:
                    Main.panic("Illegal term operator: " + k + "!");
            }
        }
        return v;
    }
}
