package no.uio.ifi.asp.parser;


import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;

import java.util.ArrayList;

import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspAssignment extends AspStmt {

    AspName name;
    ArrayList<AspSubscription> subs = new ArrayList<>();
    AspExpr expr;

    AspAssignment(int n) {
        super(n);
    }

    static AspAssignment parse(Scanner s) {

        Main.log.enterParser("assignment");
        AspAssignment aa = new AspAssignment(s.curLineNum());
        aa.name = AspName.parse(s);

        while (true) {
            if (s.curToken().kind == equalToken) break;
            aa.subs.add(AspSubscription.parse(s));
        }

        skip(s, equalToken);
        aa.expr = AspExpr.parse(s);
        skip(s, newLineToken);

        Main.log.leaveParser("assignment");
        return aa;
    }

    @Override
    void prettyPrint() {
        name.prettyPrint();
        for (AspSubscription as: subs) {
            as.prettyPrint();
        }
        Main.log.prettyWrite(" = ");
        expr.prettyPrint();
        Main.log.prettyWriteLn();
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        RuntimeValue v;
        if (subs.isEmpty()) {
            v = expr.eval(curScope);
            curScope.assign(name.name.name, v);
            trace(name.name.name + " = " + v);

            return v;
        } else {
            v = name.eval(curScope);
            for (int i = 0; i < subs.size()-1; i++) {
                RuntimeValue v2 = subs.get(i).eval(curScope);

                v = v.evalSubscription(v2,this);
            }
            RuntimeValue v2 = subs.get(subs.size()-1).eval(curScope);
            RuntimeValue v3 = expr.eval(curScope);
            v.evalAssignElem(v2, v3, this);
            trace(name.name.name + " = " + v);
            return v;
        }
    }
}

