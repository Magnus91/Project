package no.uio.ifi.asp.parser;

import java.util.ArrayList;
import java.util.function.BinaryOperator;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspBooleanLiteral extends AspAtom {

    Token bool;
    boolean value;

    AspBooleanLiteral(int n) {
        super(n);
    }

    static AspBooleanLiteral parse(Scanner s) {

        Main.log.enterParser("boolean literal");
        AspBooleanLiteral abl = new AspBooleanLiteral(s.curLineNum());
        abl.bool = s.curToken();
        if(abl.bool.kind == trueToken) {
            abl.value = true;
            skip(s, trueToken);
        } else {
            abl.value = false;
            skip(s, falseToken);
        }
        Main.log.leaveParser("boolean literal");
        return abl;
    }

    @Override
    void prettyPrint() {
        Main.log.prettyWrite(bool.kind.toString());
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        return new RuntimeBoolValue(value);
    }
}
