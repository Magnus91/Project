package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;


public class AspListDisplay extends AspAtom {

    ArrayList<AspExpr> exprs = new ArrayList<>();

    AspListDisplay (int n) {
        super(n);
    }

    static AspListDisplay parse(Scanner s) {

        Main.log.enterParser("list display");
        AspListDisplay ald = new AspListDisplay(s.curLineNum());

        skip(s, leftBracketToken);

        while (true) {
            if (s.curToken().kind == rightBracketToken) break;
            ald.exprs.add(AspExpr.parse(s));
            if (s.curToken().kind != commaToken) break;
            skip(s, commaToken);
        }

        skip(s, rightBracketToken);

        Main.log.leaveParser("list display");
        return ald;
    }

    @Override
    void prettyPrint() {
        int nPrinted = 0;
        Main.log.prettyWrite("[");
        for(AspExpr ae: exprs) {
            if (nPrinted > 0)
                Main.log.prettyWrite(", ");
            ae.prettyPrint();
            nPrinted++;
        }
        Main.log.prettyWrite("]");
    }
    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
        //-- Must be changed in part 3:
        ArrayList<RuntimeValue> listValue = new ArrayList<>();
        for (AspExpr ae:exprs) {
            listValue.add(ae.eval(curScope));
        }
        return new RuntimeListValue(listValue);
    }
}
