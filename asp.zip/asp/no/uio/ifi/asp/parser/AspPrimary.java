package no.uio.ifi.asp.parser;

import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspPrimary extends AspSyntax {

    AspAtom atom;
    ArrayList<AspPrimarySuffix> aspPrimarySuffixes = new ArrayList<>();

    AspPrimary(int n) {
        super(n);
    }

    static AspPrimary parse(Scanner s) {

        Main.log.enterParser("primary");
        AspPrimary ap = new AspPrimary(s.curLineNum());
        ap.atom = AspAtom.parse(s);

        while(true) {
            if (s.curToken().kind == leftParToken || s.curToken().kind == leftBracketToken) {
                ap.aspPrimarySuffixes.add(AspPrimarySuffix.parse(s));
            } else {
                break;
            }
        }

        Main.log.leaveParser("primary");
        return ap;
    }

    @Override
    void prettyPrint() {
        atom.prettyPrint();
        for(AspPrimarySuffix aps: aspPrimarySuffixes) {
            aps.prettyPrint();
        }
    }

    @Override
    public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {

        RuntimeValue v = atom.eval(curScope);

        for(int i = 0; i < aspPrimarySuffixes.size(); i++) {
            RuntimeValue v2 = aspPrimarySuffixes.get(i).eval(curScope);
            if(aspPrimarySuffixes.get(i) instanceof AspSubscription) {
                v = v.evalSubscription(v2,this);
            }
            else if(aspPrimarySuffixes.get(i) instanceof AspArguments) {
                ArrayList<RuntimeValue> arguments = v2.getListValue("arguments", this);
                trace("Call function "+ v.toString() + " with arguments" + arguments);
                v = v.evalFuncCall(arguments, this);
            }
        }
        return v;
    }
}
